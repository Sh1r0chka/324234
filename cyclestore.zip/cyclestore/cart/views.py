from django.shortcuts import render, redirect, HttpResponse
from .models import CartItem
from main.models import Tovar
from django.views.generic import DetailView, ListView
from .models import CartItem, Order
from .models import Order

# ----------------------CART-----------------------------

def view_cart(request):
    if request.user.is_authenticated:
        cart_items = CartItem.objects.filter(user=request.user)
        total_price = sum(item.tovar.tovarprice * item.quantity for item in cart_items)
        return render(
            request,
            "cart/cart.html",
            {"cart_items": cart_items, "total_price": total_price},
        )
    else:
        return render(request, "account/signup.html")


def add_to_cart(request, tovar_id):
    tovar = Tovar.objects.get(id=tovar_id)
    cart_item, created = CartItem.objects.get_or_create(tovar=tovar, user=request.user)
    cart_item.quantity += 1
    cart_item.save()
    return redirect("cart:view_cart")


def remove_from_cart(request, item_id):
    cart_item = CartItem.objects.get(id=item_id)
    cart_item.delete()
    return redirect("cart:view_cart")


# ----------------------ORDER-----------------------------

def create_order_from_cart(request):
    if request.method == "POST":
        user = request.user
        cart_items = CartItem.objects.filter(user=user)

        if cart_items.exists():
            order = Order(user=user)
            order.save()
            order.cart_items.set(cart_items)
            order.save()
            return redirect("order-detail", pk=order.pk)
        else:
            return render(request, "cart.html")
    else:
        return render(request, "cart.html")


class OrderList(ListView):
    model = Order
    context_object_name = "order"


class OrderDetail(DetailView):
    model = Order
    template_name = "cart/order-detail.html"
    context_object_name = "order"


def view_orders(request):
    context = Order.objects.filter(user=request.user)
    return render(request, "cart/orders.html", context)
