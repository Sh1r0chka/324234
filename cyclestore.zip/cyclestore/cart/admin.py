from django.contrib import admin
from .models import Order,CartItem

admin.site.register(Order)
admin.site.register(CartItem)




